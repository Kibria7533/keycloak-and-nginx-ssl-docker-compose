# Keycloak Action token validation API module

Custom REST API for Keycloak that does validation of action tokens that were issued by Keycloak. Example of those tokens
are verify email, reset credentials...

## Build
Run `mvn clean package`

## Requirements
Java 17 (can be changed in `pom.xml`)  
Keycloak 21.1.1

## Security

API is protected. It can be called using Bearer token that was issued to account that has manage-users (
realm-management -> manage-users) role (usually service-account).

## Usage

Compiled jar needs to be deployed inside providers directory of Keycloak installation. After running build command (
kc.sh build) or starting it in dev mode.

### Validation Endpoint

**Exposed at:**
[{base_url}/realms/{realm}/action-token-api/validate-token]()  
**Accepts:** Query parameter token  
**Example:**  
curl
--location 'http://localhost:8080/realms/Test/action-token-api/validate-token?token=eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIzM2M5NDdlMy1lZDVkLTRjMmUtYTEyNi1lZjJmMWJiNTlkMGUifQ.eyJleHAiOjE2OTUxNTcwMzYsImlhdCI6MTY5NTExMzgzNiwianRpIjoiYmM3M2M4N2QtNDgzNy00NjM1LWE1Y2ItY2M4MTNlZjYwN2I5IiwiaXNzIjoiaHR0cHM6Ly9kZXYtc3NvLmhydmF0c2tpdGVsZWtvbS5oci9hdXRoL3JlYWxtcy9IVEV4dGVybmFsIiwiYXVkIjoiaHR0cHM6Ly9kZXYtc3NvLmhydmF0c2tpdGVsZWtvbS5oci9hdXRoL3JlYWxtcy9IVEV4dGVybmFsIiwic3ViIjoiMzEwNTcyIiwidHlwIjoiZXhlY3V0ZS1hY3Rpb25zIiwiYXpwIjoiYWNjb3VudCIsIm5vbmNlIjoiYmM3M2M4N2QtNDgzNy00NjM1LWE1Y2ItY2M4MTNlZjYwN2I5IiwicnFhYyI6WyJVUERBVEVfUEFTU1dPUkQiXSwicnFhYyI6WyJVUERBVEVfUEFTU1dPUkQiXX0.jByZ68h2OOtOZj2sXP0MW1E38GyEw1hylHG7nDMfXT4' \
--header 'Authorization: Bearer
eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJPOUF1anhCRmdCYzV1X1ZyQV9YQ1A0bEZ0Zmw2SGpiRmd4MC1sOUdjbDlJIn0.eyJleHAiOjE2OTU0OTk4NjAsImlhdCI6MTY5NTQ5OTU2MCwianRpIjoiYWRhYjk3YWItNzNhNy00YWIwLWI1MGItZGY4NzUyZGQyZTE3IiwiaXNzIjoiaHR0cDovLzAuMC4wLjA6ODA4MC9yZWFsbXMvVGVzdCIsImF1ZCI6WyJyZWFsbS1tYW5hZ2VtZW50IiwiYWNjb3VudCJdLCJzdWIiOiIzODdmN2RiMS00MDViLTQ3YjItODhmYi01ZmM2NzcwODJkZGEiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJ0ZXN0IiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyIvKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiZGVmYXVsdC1yb2xlcy10ZXN0Iiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7InJlYWxtLW1hbmFnZW1lbnQiOnsicm9sZXMiOlsibWFuYWdlLXVzZXJzIl19LCJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6ImVtYWlsIHByb2ZpbGUiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImNsaWVudEhvc3QiOiIxMjcuMC4wLjEiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzZXJ2aWNlLWFjY291bnQtdGVzdCIsImNsaWVudEFkZHJlc3MiOiIxMjcuMC4wLjEiLCJjbGllbnRfaWQiOiJ0ZXN0In0.HZXiBtffFFWxPMwzXzbz3-eRenvrSaCfA0qAAKtCta9rKe8nqAA41mhz39u0U85v0w1uSzZ0D6TGAxpBHBCaTnTaJ62K3dnMPQgsr4H3SvmFeB0Xwo7Jm7pUf6BuWbL1jwWmc8fknlugXPRtRq5784XOiDiO7C97I5xPws39wgOVH-W377DwabVf-SZoTzyQf8ZV0bnW3G050UTbMUrj5hUmlcB3bAzHxQ8bBJDS9XifkxzZzOJUzqpbS5uX2gdi0ds3TvLCEulVb3DD09k4EifzGkI8w15tbz0MEbPpy2YN6ViiFVmETTlzSBqdNf2Lb4x1OKOYAQGbOEohV93xyw'

**Response:**

    {
        "valid":true,
        "action":"reset-credentials",
        "userId":"249c48ff-3e18-4c5a-9ee5-444ce58d78dd"
    }

or

    {
        "valid":false,
        "message":"Token is not active"
    }

