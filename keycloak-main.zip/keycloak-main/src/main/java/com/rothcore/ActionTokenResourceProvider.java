package com.rothcore;

import org.jboss.logging.Logger;
import org.keycloak.TokenVerifier;
import org.keycloak.authentication.actiontoken.ActionTokenContext;
import org.keycloak.authentication.actiontoken.ActionTokenHandler;
import org.keycloak.authentication.actiontoken.ExplainedTokenVerificationException;
import org.keycloak.common.ClientConnection;
import org.keycloak.common.VerificationException;
import org.keycloak.crypto.SignatureProvider;
import org.keycloak.crypto.SignatureVerifierContext;
import org.keycloak.events.Errors;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.http.HttpRequest;
import org.keycloak.jose.jws.JWSInput;
import org.keycloak.jose.jws.JWSInputException;
import org.keycloak.models.DefaultActionTokenKey;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.SingleUseObjectKeyModel;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.JsonWebToken;
import org.keycloak.services.Urls;
import org.keycloak.services.managers.AppAuthManager;
import org.keycloak.services.managers.AuthenticationManager;
import org.keycloak.services.managers.RealmManager;
import org.keycloak.services.messages.Messages;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.services.resources.LoginActionsServiceChecks;
import org.keycloak.services.resources.admin.AdminAuth;
import org.keycloak.services.resources.admin.permissions.AdminPermissionEvaluator;
import org.keycloak.services.resources.admin.permissions.AdminPermissions;
import org.keycloak.sessions.AuthenticationSessionCompoundId;
import org.keycloak.sessions.AuthenticationSessionModel;

import javax.ws.rs.*;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.keycloak.authentication.actiontoken.DefaultActionToken.ACTION_TOKEN_BASIC_CHECKS;

public class ActionTokenResourceProvider implements RealmResourceProvider {

    private static final Logger logger = Logger.getLogger(ActionTokenResourceProvider.class);
    public static final String FAILED_TO_VALIDATE_TOKEN_MESSAGE = "Failed to validate token. Exception: %s, message: %s";

    private final KeycloakSession session;

    private final ClientConnection clientConnection;

    private final RealmModel realm;

    private final HttpRequest request;

    private final EventBuilder event;

    private final HttpHeaders headers;

    public ActionTokenResourceProvider(KeycloakSession session, EventBuilder event) {
        this.session = session;
        this.clientConnection = session.getContext().getConnection();
        this.realm = session.getContext().getRealm();
        this.request = session.getContext().getHttpRequest();
        this.headers = session.getContext().getRequestHeaders();
        this.event = event;
    }

    @Override
    public Object getResource() {
        return this;
    }

    @GET
    @Path("validate-token")
    public <T extends JsonWebToken & SingleUseObjectKeyModel> Response validateToken(@QueryParam("token") String tokenString) {
        TokenValidationResponse tokenValidationResponse = new TokenValidationResponse(false);

        try {
            validateAccessToken();
        } catch (ForbiddenException ex) {
            logger.debugf(FAILED_TO_VALIDATE_TOKEN_MESSAGE, ex.getClass().getName(), ex.getMessage());
            return Response.status(Response.Status.FORBIDDEN).entity(tokenValidationResponse).type(MediaType.APPLICATION_JSON_TYPE).build();
        }

        logger.debug("Validating action token");
        T token;
        ActionTokenHandler<T> handler;
        ActionTokenContext<T> tokenContext;


        AuthenticationSessionModel authSession = null;

        event.event(EventType.EXECUTE_ACTION_TOKEN);

        try {
            if (tokenString == null) {
                throw new ExplainedTokenVerificationException(null, Errors.NOT_ALLOWED, Messages.INVALID_REQUEST);
            }

            TokenVerifier<DefaultActionTokenKey> tokenVerifier = TokenVerifier.create(tokenString, DefaultActionTokenKey.class);
            DefaultActionTokenKey aToken = tokenVerifier.getToken();

            handler = resolveActionTokenHandler(aToken.getActionId());

            if (!realm.isEnabled()) {
                throw new ExplainedTokenVerificationException(aToken, Errors.REALM_DISABLED, Messages.REALM_NOT_ENABLED);
            }
            if (!checkSsl()) {
                throw new ExplainedTokenVerificationException(aToken, Errors.SSL_REQUIRED, Messages.HTTPS_REQUIRED);
            }

            TokenVerifier<DefaultActionTokenKey> verifier = tokenVerifier
                    .withChecks(
                            TokenVerifier.IS_ACTIVE,
                            new TokenVerifier.RealmUrlCheck(Urls.realmIssuer(session.getContext().getUri().getBaseUri(), realm.getName())),
                            ACTION_TOKEN_BASIC_CHECKS
                    );

            String kid = verifier.getHeader().getKeyId();
            String algorithm = verifier.getHeader().getAlgorithm().name();

            SignatureVerifierContext signatureVerifier = session.getProvider(SignatureProvider.class, algorithm).verifier(kid);
            verifier.verifierContext(signatureVerifier);

            verifier.verify();

            token = TokenVerifier.create(tokenString, handler.getTokenClass()).getToken();

        } catch (Exception ex) {
            logger.debugf(FAILED_TO_VALIDATE_TOKEN_MESSAGE, ex.getClass().getName(), ex.getMessage());
            tokenValidationResponse.setMessage(ex.getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(tokenValidationResponse).type(MediaType.APPLICATION_JSON_TYPE).build();
        }

        tokenContext = new ActionTokenContext(session, realm, session.getContext().getUri(), clientConnection, request, event, handler, null, null, null);

        try {
            String tokenAuthSessionCompoundId = handler.getAuthenticationSessionIdFromToken(token, tokenContext, authSession);

            if (tokenAuthSessionCompoundId != null) {
                String sessionId = AuthenticationSessionCompoundId.encoded(tokenAuthSessionCompoundId).getRootSessionId();
                LoginActionsServiceChecks.checkNotLoggedInYet(tokenContext, authSession, sessionId);
            }

            authSession = handler.startFreshAuthenticationSession(token, tokenContext);
            tokenContext.setAuthenticationSession(authSession, true);

            event.event(handler.eventType());

            LoginActionsServiceChecks.checkIsUserValid(token, tokenContext);
            LoginActionsServiceChecks.checkIsClientValid(token, tokenContext);

            session.getContext().setClient(authSession.getClient());

            TokenVerifier.createWithoutSignature(token)
                    .withChecks(handler.getVerifiers(tokenContext))
                    .verify();

        } catch (Exception ex) {
            logger.debugf(FAILED_TO_VALIDATE_TOKEN_MESSAGE, ex.getClass().getName(), ex.getMessage());
            tokenValidationResponse.setMessage(ex.getMessage());
            return Response.status(Response.Status.BAD_REQUEST).entity(tokenValidationResponse).type(MediaType.APPLICATION_JSON_TYPE).build();
        }

        logger.debug("Token validation successful.");
        tokenValidationResponse.setValid(true);
        tokenValidationResponse.setUserId(token.getUserId());
        tokenValidationResponse.setAction(token.getActionId());
        return Response.ok(tokenValidationResponse).type(MediaType.APPLICATION_JSON_TYPE).build();
    }

    private void validateAccessToken() {
        logger.debug("Checking for Bearer token before validating action token");
        String tokenString = AppAuthManager.extractAuthorizationHeaderToken(headers);
        if (tokenString == null) throw new NotAuthorizedException("Bearer");
        AccessToken token;
        try {
            JWSInput input = new JWSInput(tokenString);
            token = input.readJsonContent(AccessToken.class);
        } catch (JWSInputException e) {
            throw new NotAuthorizedException("Bearer token format error");
        }
        String realmName = token.getIssuer().substring(token.getIssuer().lastIndexOf('/') + 1);
        RealmManager realmManager = new RealmManager(session);
        RealmModel realm = realmManager.getRealmByName(realmName);
        if (realm == null) {
            throw new NotAuthorizedException("Unknown realm in token");
        }
        session.getContext().setRealm(realm);

        AuthenticationManager.AuthResult authResult = new AppAuthManager.BearerTokenAuthenticator(session)
                .setRealm(realm)
                .setConnection(session.getContext().getConnection())
                .setHeaders(headers)
                .authenticate();

        if (authResult == null) {
            logger.debug("Token not valid");
            throw new NotAuthorizedException("Bearer");
        }

        AdminAuth auth = new AdminAuth(realm, authResult.getToken(), authResult.getUser(), authResult.getClient());

        AdminPermissionEvaluator realmAuth = AdminPermissions.evaluator(session, realm, auth);

        realmAuth.users().requireManage();
    }

    private <T extends JsonWebToken> ActionTokenHandler<T> resolveActionTokenHandler(String actionId) throws VerificationException {
        if (actionId == null) {
            throw new VerificationException("Action token operation not set");
        }
        ActionTokenHandler<T> handler = session.getProvider(ActionTokenHandler.class, actionId);

        if (handler == null) {
            throw new VerificationException("Invalid action token operation");
        }
        return handler;
    }

    private boolean checkSsl() {
        if (session.getContext().getUri().getBaseUri().getScheme().equals("https")) {
            return true;
        } else {
            return !realm.getSslRequired().isRequired(clientConnection);
        }
    }

    @Override
    public void close() {

    }
}