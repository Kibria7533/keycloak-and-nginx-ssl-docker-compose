package com.rothcore;

import org.keycloak.Config;
import org.keycloak.events.EventBuilder;
import org.keycloak.models.KeycloakContext;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.RealmModel;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.services.resource.RealmResourceProviderFactory;

public class ActionTokenResourceProviderFactory implements RealmResourceProviderFactory {
    public static final String ID = "action-token-api";

    @Override
    public RealmResourceProvider create(KeycloakSession keycloakSession) {
        KeycloakContext context = keycloakSession.getContext();
        RealmModel realm = context.getRealm();
        EventBuilder event = new EventBuilder(realm, keycloakSession, context.getConnection());
        return new ActionTokenResourceProvider(keycloakSession, event);
    }

    @Override
    public void init(Config.Scope scope) {

    }

    @Override
    public void postInit(KeycloakSessionFactory keycloakSessionFactory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return ID;
    }
}
